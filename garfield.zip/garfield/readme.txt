You will need: bash and wget, afaik that's pretty much everywhere.
Change thisyear, thismonth and thisday in garfield.sh to today's date (or the date which should be the last it downloads).
Run ./garfield.sh
Wait for it to download all the strips, that might take quite some time (it's about 300mb, each year around 10mb).
Run ./mkpages.sh
That will create html pages with easy navigation.
Alter style.css to your liking, if you don't like mine.
Enjoy :-)
