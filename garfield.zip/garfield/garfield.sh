#!/bin/bash
# downloads all the wonderful Garfield comic strips
# script by Vit `tasuki' Brunner

# write the current date here so the script knows where to stop
thisyear=2006
thismonth=12
thisday=24

# 1978-06-19 was the first Garfield comic strip
# you can rewrite this to anything you want if you
# are only trying to complete your collection
firstyear=1978
firstmonth=6
firstday=19

for ((year=firstyear; year<=thisyear; year++)); do # do for all the years
  if ((year<2000)); then
    yy=$((year-1900))    # make the year two digit
  else
    if ((year<2010)); then
      yy=0$((year-2000)) # add zero before single digit years
    else
      yy=$((year-2000))  # distant future...
    fi
  fi
  
  for ((mon=1; mon<=12; mon++)); do # do for all the months
    if ((mon<10)); then
      mm=0$mon           # add zero before single digit month
    else                 # $mm is stringish while $mon is numeral
      mm=$mon
    fi
    
    for ((day=1; day<=31; day++)); do # do for every day in a month
      if ((day<10)); then
        dd=0$day         # add zero to single digit days
      else               # $dd is stringish and $day numeral
        dd=$day
      fi
      
      # any diff year is ok,  later month as well  or current month and day at least today
      if (( year>firstyear || mon>firstmonth || (mon==firstmonth && day>=firstday) )) ; then
        # any diff year is ok,  sooner month as well  or current month and sooner day
        if (( year<thisyear || mon<thismonth || (mon==thismonth && day<=thisday ) )) ; then
          # 30day months ok, february sucks - too lazy to care about leap years;
          if (( !( ( (mon==4 || mon==6 || mon==9 || mon==11) && day==31) || (day>29 && mon==2) ) )) ; then
            wget -t 0 -c http://images.ucomics.com/comics/ga/$year/ga$yy$mm$dd.gif
            #echo "http://images.ucomics.com/comics/ga/$year/ga$yy$mm$dd.gif"
          fi
        fi
      fi
    done
  done
  mkdir $year
  mv ga$yy* $year
done

