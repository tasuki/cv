#!/bin/bash
# makes web pages for garfield comic strips downloaded by garfield.sh
# feel free to rewrite style.css to suit you better
# script by Vit `tasuki' Brunner

echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
  <title>Garfield collection</title>
  <link rel="stylesheet" type="text/css" title="default" href="style.css"/>
</head>
<body>
<h1>Garfield</h1>
' > index.html

for folder in * ; do
  if [ -d $folder ] ; then
  echo "<p class=\"main\"><a href=\"$folder.html\">$folder</a></p>" >> index.html
  echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict. +dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\">
<head>
  <title>Garfield collection from year $folder</title>
  <link rel=\"stylesheet\" type=\"text/css\" title=\"default\" href=\"style.css\"/>
</head>
<body>
<h1>Garfield $folder</h1>
<p><a href=\"index.html\">back to index</a></p>
<table cellpadding=\"5\"><tr>
  <td><a href=\"#January\">January</a></td>
  <td><a href=\"#February\">February</a></td>
  <td><a href=\"#March\">March</a></td>
  <td><a href=\"#April\">April</a></td>
  <td><a href=\"#May\">May</a></td>
  <td><a href=\"#June\">June</a></td>
</tr><tr>
  <td><a href=\"#July\">July</a></td>
  <td><a href=\"#August\">August</a></td>
  <td><a href=\"#September\">September</a></td>
  <td><a href=\"#October\">October</a></td>
  <td><a href=\"#November\">November</a></td>
  <td><a href=\"#December\">December</a></td>
</tr></table>
" > $folder.html
    for picture in `ls $folder`
    do
      new=`echo $picture | cut -c5-6`
      if [ "$new" != "$old" ] ; then
        case "$new" in
          01)
            month="January";;
          02)
            month="February";;
          03)
            month="March";;
          04)
            month="April";;
          05)
            month="May";;
          06)
            month="June";;
          07)
            month="July";;
          08)
            month="August";;
          09)
            month="September";;
          10)
            month="October";;
          11)
            month="November";;
          12)
            month="December";;
        esac
        echo "<h2><a name=\"$month\">$month</a></h2>" >> $folder.html
      fi
      old=$new
      echo "<p><img src=\"$folder/$picture\" alt=\"garfield\"/></p>" >> $folder.html
    done
    echo "</body></html>" >> $folder.html
  fi
done

echo "</body>
</html>" >> index.html
